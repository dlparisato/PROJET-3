//
//  Character.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Character {
    
    
    // MARK: -  PROPERTIES
    
    // On a besoin du personnage qui a un nom, un point d'appui et une arme.
    var nameHero : String
    var lifePoint : Int
    var weapon : Weapon
    
    
    //MARK:- INITIALIZER
    
    // Initialisation des variables ci-dessus.
    init(nameHero: String, lifePoint: Int, weapon: Weapon) {
        self.nameHero = nameHero
        self.lifePoint = lifePoint
        self.weapon = weapon
    }
    
    // MARK: - METHODS
    
    
    // Fonction attack permet à un personnage d'infliger ses points de dégâts à l'adversaire.
    /// - parameter target : retourner au personnage cible pour l'attaque.
    func attack(target: Character) {
        target.lifePoint -= self.weapon.damageWeapon
        
        print("\(self.nameHero) attaque  \(target.nameHero) et lui infligé \(self.weapon.damageWeapon) pts de vie 💥💥. \(target.nameHero) a maintenant \(target.lifePoint) pts de vie 💔 ")
        
        /// boucle pour vérifier si le personnage est vivant.
        if target.lifePoint <= 0 {
            target.lifePoint = 0
            print("""
                
            😞😭😞😭 \(target.nameHero) n'a plus de vie 😞😭😞😭
                
            """)
            
           
        }
    }
}



