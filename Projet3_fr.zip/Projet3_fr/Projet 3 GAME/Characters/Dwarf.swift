//
//  Dwarf.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Dwarf: Character {
    
    
    // MARK: - PROPRIETES
    
    
    // La variable maxilifePoint permet au code de soustraire les dommages de DWARF lifePoint.
    static var maxiLifePoint = 80
    
    // La variable defautWeapon initialise DWARF avec les valeurs d'armes par défaut.
    static private let defaultWeapon = Weapon(nameWeapon: "Hatchet", damageWeapon: 20, heal: 0)
    
    
    // MARK: - INITIALIZER
    
    
    // Initialiser la classe DWARF grâce au Character initialise
    /// - Parameter nameHero: nameHero appelle la valeur stockée dans le tableau.
    init(nameHero: String) {
        super.init(nameHero: nameHero, lifePoint: Dwarf.maxiLifePoint, weapon: Dwarf.defaultWeapon)
    }
    
    
    // MARK: - METHODES
    
    
    // La fonction permettent d'ajouter des statistiques de Character.
    ///Cette fonction est utilisée pour aider le joueur à choisir un personnage. On lui présente toutes les statistiques de DWARF.
    static func features() -> String {
        // "DWARF a (80) points de vie et son arme (HATCHET) et a (20) points de dégâts"
        return "Dwarf a \(Dwarf.maxiLifePoint) pts de vie 💙, a son arme \(Dwarf.defaultWeapon.nameWeapon) 🪓🪓 et a \(Dwarf.defaultWeapon.damageWeapon) pts de dégâts 💥💥💥"
    }
}

