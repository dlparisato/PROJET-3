//
//  Warrior.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation


class Warrior: Character {
    
    
    // MARK: - PROPERTIES
    
    
    // La variable maxilifePoint permet au code de soustraire les dommages de WARRIOR lifePoint.
    static var maxiLifePoint = 100
    
    // La variable defautWeapon initialise WARRIOR avec les valeurs d'armes par défaut.
    static private let defaultWeapon = Weapon(nameWeapon: "Sword", damageWeapon: 15, heal: 0)

    
    // MARK: - INITIALIZER
    
    
    // Initialiser la classe WARRIOR grâce au Character initialise
    /// - Parameter nameHero: nameHero appelle la valeur stockée dans le tableau.
    init(nameHero: String) {
        super.init(nameHero: nameHero, lifePoint: Warrior.maxiLifePoint, weapon: Warrior.defaultWeapon)
    }
    
    
    // MARK: - METHODS
    
    
    // La fonction permettent d'ajouter des statistiques de Character.
    ///Cette fonction est utilisée pour aider le joueur à choisir un personnage. On lui présente toutes les statistiques de WARRIOR.
    static func features() -> String {
        
        /// Display text: "WARRIOR a (100) points de vie et son arme (SWORD) et a (15) points de dégâts"
        return "Warrior a \(Warrior.maxiLifePoint) pts de vie 💙 et a son arme \(Warrior.defaultWeapon.nameWeapon) 🗡🗡 et a \(Warrior.defaultWeapon.damageWeapon) pts de dégâts 💥💥💥"
    }
}
