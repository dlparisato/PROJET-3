//
//  Wizard.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Wizard: Character {
    
    
    // MARK: - PROPERTIES
    
    // La variable maxilifePoint permet au code de soustraire les dommages de WIZARD lifePoint.
    static var maxLifePoint = 90
    
    // La variable defautWeapon initialise WIZARD avec les valeurs d'armes par défaut.
    static private let defaultWeapon = Weapon(nameWeapon: "Electrical Attack", damageWeapon: 5, heal: 10)
    
    
    // MARK: - INITIALIZER
    
    
    // Initialiser la classe WIZARD grâce au Character initialise
    /// - Parameter nameHero: nameHero appelle la valeur stockée dans le tableau.
    init(nameHero: String) {
        super.init(nameHero: nameHero, lifePoint: Wizard.maxLifePoint, weapon: Wizard.defaultWeapon)
    }
    
    
    // MARK: - METHODS
    
    
    // La fonction permettent d'ajouter des statistiques de Character.
    /// Cette fonction est utilisée pour aider le joueur à choisir un personnage. On lui présente toutes les statistiques de WIZARD..
    static func features() -> String {
        
        /// "WIZARD a (90) points de vie et son arme (Electrical Attack),  a (5) points de dégâts et a (10) points de soins"
        return "Wizard a \(Wizard.maxLifePoint) pts de vie 💙, a son arme \(Wizard.defaultWeapon.nameWeapon) ⚡️⚡️ , a \(Wizard.defaultWeapon.damageWeapon) pts de dégâts 💥💥💥  et a \(Wizard.defaultWeapon.heal) pts de soins 💚"
    }
    
    // La fonction de guérison rétablit le point de vie du personnage choisi dans l'équipe.
    /// - Parameter target: Return to target character for healing.
    func heal(target: Character) {
        target.lifePoint = target.lifePoint + self.weapon.heal
    }
}

