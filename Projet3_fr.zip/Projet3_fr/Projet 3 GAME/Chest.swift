//
//  Chest.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 12/02/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Chest {
    
    
    // MARK: - ENUMERATION
    
    enum AttackType {
        case magic, attack
    }
    
    // MARK: - PROPERTIES
    
    private let newWeapon = ""
    private let damage = 30
    private let magicWeapon = Weapon(nameWeapon: "Magic Weapon", damageWeapon: 0, heal: 10)
    private let specialWeapon = Weapon(nameWeapon: "Special Weapon", damageWeapon: 25, heal: 0)
    
    
    // MARK: - METHODS
    
    // Fonction Arme aléatoire (une arme spéciale) lorsque vous tombez sur le coffre
    func randomWeapon(type: AttackType) -> Weapon? {
        let randomInt = Int.random(in: 1...3)
        if randomInt == 2 {
            
            /// Cette condition déduit le type du personnage afin de lui attribuer un coffre approprié.
            if type == .attack {
                return specialWeapon
            } else {
                return magicWeapon
            }
            /// retour nul si la chance n'est pas égale à 2
        }
        return nil
    }
}
