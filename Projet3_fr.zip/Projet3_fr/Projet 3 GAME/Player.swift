//
//  Player.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Player {
    
    
    // MARK: - PROPERTIES
    
    
    // Le variable playerNumber contiendra le numéro du joueur.
    var playerNumber: Int
    
    // Cette variable stocke dans un tableau des personnages choisis par un joueur pour créer une équipe.
    var team = [Character]()
    
    // La variable stocke dans un tableau. Les noms des personnages choisis par le joueur.
    static private var namesTable = [String]()
    
    
    // MARK: - INITIALIZER

    
    // Initialiser la variable playerNumber.
    init(playerNumber: Int) {
        self.playerNumber = playerNumber
    }
    
    
    // MARK: - METHODS

    
    // Fonction a mis le nom que le joueur a choisi pour son personnage.
    /// On vérifie  que le nom est écrit sans espaces de plus de 3 caractères. Et on assure que le nom ne l'est pas déjà.
    private func nameCharacter() -> String {
        if let namePlayer = readLine() {
            
            /// Si le nom contient des espaces et ou moins de 3 caractères, un message d'erreur est renvoyé.
            let choice = namePlayer.trimmingCharacters(in: .whitespaces)
            if choice.count < 3 || Player.namesTable.contains(choice) {
                print("Choisissez un nom de plus de 3 caractères et qui n'existe pas encore")
            } else {
                Player.namesTable.append(choice)
                
                return choice
            }
        }
        return nameCharacter()
    }
    
    
    // La fonction createTeam initialise l'équipe.
    func createTeam() {
        /// Si le joueur n'a pas ces 3 personnages, le jeu ne peut pas commencer.
        while team.count < 3 {
            /// On affiche la liste des personnages disponibles et leurs caractéristiques.
            print("""
                
                           👤 Joueur \(playerNumber) choisissez 3 personnages dans la liste ci-dessous :
                           =============================================================================
                
                1. \(Warrior.features())
                
                2. \(Wizard.features())
                
                3. \(Dwarf.features())
                
                """)
            
            /// On demande le choix du joueur entre 1 et 3.
            if let choice = readLine() {
                switch choice {
                case "1" :
                    print("""
                        
                    Tu as choisi le WARRIOR 🦸🏻‍♀️ donne-lui un nom :
                        
                    """)
                    
                    /// Demander le nom du personnage
                    let nameHero = nameCharacter()
                    let character = Warrior(nameHero: nameHero)
                    
                    /// Ajouter le personnage à créer à l'équipe.
                    team.append(character)
                    
                    
                case "2" :
                    print("""
                        
                    Tu as choisi le WIZARD 🧙‍♂️ donne-lui un nom :
                        
                    """)
                    
                    let nameHero = nameCharacter()
                    let character = Wizard(nameHero: nameHero)
                    
                    team.append(character)
                    
                
                case "3" :
                    print("""
                        
                    Tu as choisi le DWARF 🧑‍🚒 donne-lui un nom :
                        
                    """)
                    
                    let nameHero = nameCharacter()
                    let character = Dwarf(nameHero: nameHero)
            
                    team.append(character)
                    
                    
                default:
                    print("Saisi un chiffre entre 1 et 3")
                }
            }
        }
        print(Player.namesTable.count)
        print(Player.namesTable)
    }
    
    
    // La fonction selectCharacter permet de choisir un personnage dans une équipe.
    ///- Parameter : on affiche la liste des personnages de l'équipe contenue dans le tableau.
    func selectCharacter(team: [Character]) -> Character {
        for (index, character) in team.enumerated() {
            
            if let wizard = character as? Wizard{
                print(" -> le personnage \(index + 1) s'appelle \(wizard.nameHero), est un \(type(of: wizard)) , sa vie \(wizard.lifePoint) , ses dégâts \(wizard.weapon.damageWeapon) et son soins \(wizard.weapon.heal)")
            } else {
                /// We display the full list of teams.
                print(" -> le personnage \(index + 1) s'appelle \(character.nameHero), est un \(type(of: character)) , sa vie \(character.lifePoint) et ses dégâts \(character.weapon.damageWeapon) ")
            }
        }
        
    // Cette boucle permet d'écouter le choix du personnage par le joueur.
    /// Vérifier que le nombre est compris entre 1 et team.count, vous ne pouvez pas choisir un personnage mort.
        if let choice = readLine() {
            if let choiceInt = Int(choice) {
                if choiceInt >= 1 && choiceInt <= team.count {
                    return team[choiceInt - 1]
                }
            }
        }
        // Retour fonction selecCharacter.
        return selectCharacter(team: team)
    }
}



