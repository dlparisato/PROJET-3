//
//  Game.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Game {
    
    
    // MARK: - PROPERTIES
    
    
    // Variables qui initialisent Player
    var player1: Player
    var player2: Player
    
    // On contient le nombre de tours dans le jeu pour afficher les statistiques à la fin
    var numberRound = 0
    var arrayDead = [Character]()
    
    
    // MARK: - INITIALIZER
    
    
    init() {
        player1 = Player(playerNumber: 1)
        player1.createTeam()
        
        player2 = Player(playerNumber: 2)
        player2.createTeam()
        
    }
    
    
    // MARK: - METHODS
    
    
    // Fonction star affiche les statistiques de combat et le jeu
    func start() {
        fight()         // Add the function fight (line 159)
        statisticGame()     // Add the function game (line 68)
    }
    
    
    // La fonction teamIsAlive vérifie si tous les personnages d'une équipe sont morts
    private func teamIsAlive(player: Player) -> Bool {
        /// La boucle For In vérifie si le personnage a 0 points de vie. Et si c'est le cas, supprimez le tableau
        for(index, character) in player.team.enumerated() {
            if character.lifePoint <= 0 {
                arrayDead.append(character)
                player.team.remove(at: index)
            }
        }
        // Retourner faux lorsque toute l'équipe était morte
        if player.team.count == 0 {
            return false
        }
        // Retourner vrai quand il y a au moins un personnage 
        return true
    }
    
    
    // Fonction statistique: Le jeu affiche le vainqueur et les statistiques du jeu.
    private func statisticGame() {
        print("""
            
        |✝️|✝️|✝️|✝️|✝️|✝️|✝️|✝️| Désolé toute l'équipe est morte |✝️|✝️|✝️|✝️|✝️|✝️|✝️|✝️|
            
        """)
        
        if teamIsAlive(player: player1) {
            print("""
            ⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟

            🏆🎖🏆🎖🏆 BRAVOOO !!! Le Player 1️⃣ a gagné! 🏆🎖🏆🎖🏆

            ⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟

            """)
            
        } else {
            print("""
            ⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟

            🏆🎖🏆🎖🏆 BRAVOOO !!! Le Player 2️⃣ a gagné! 🏆🎖🏆🎖🏆
            
            ⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟⭐️🌟

            """)

        }
        print("""
        ============================================================

        Le nombre de tours: \(numberRound)
            
        ============================================================

        """)
        
        print("""
            
        💀 Les Heros morts sont 💀
            
        """)
        
        for characterDead in arrayDead {
            print(" ✝️ le personnage \(characterDead.nameHero) qui est \(type(of: characterDead)) \(characterDead.lifePoint) 💔 ")
        }
    }
    
    
    // La fonction playerRound gère le tour du joueur
    private func playerRound(attacker: Player, defender: Player) {
        let chest = Chest()
        
        // Choisissez un personnage dans l'équipe
        let attackingCharacter = attacker.selectCharacter(team: attacker.team)
        
        // Verifiez le type pour attribuer un coffre approprié au guerrier ou au guérisseur.
        /// S'il est guérisseur. On attribue une arme appropriée à Wizard
        if let wizard = attackingCharacter as? Wizard {
            if let newWeapon = chest.randomWeapon(type: .magic) {
                print("""
                    
                🎁 🎁 🎁 🧪 COFFRE MAGIQUE: Vous avez trouvé une meileure arme de guérrison 🧪 🎁 🎁 🎁
                    
                """)
                
                wizard.weapon = newWeapon
            }
            
            /// If it is a warrior character. We assign  an appropriate weapon.
            let targetCharacter = attacker.selectCharacter(team: attacker.team)
            wizard.heal(target: targetCharacter)
        } else {
            if let newWeapon = chest.randomWeapon(type: .attack) {
                print("""
                    
                🎁 🎁 🎁 ⚔️ COFFRE MAGIQUE: Vous avez touvé une meilleure arme d'attaque ⚔️ 🎁 🎁 🎁
                    
                """)
                
                attackingCharacter.weapon = newWeapon
            }
            
            // S'il s'agit d'un personnage guerrier. On attribue une arme appropriée.
            let targetCharacter = attacker.selectCharacter(team: defender.team)
            attackingCharacter.attack(target: targetCharacter)
        }
    }
    
    
    // Fonction attaque 
    private func fight() {
        // Cette boucle permet au joueur de choisir son attaque et son adversaire.
        while teamIsAlive(player: player1) && teamIsAlive(player: player2) {
            print("""
                
            ♠️♥️♣️♦️♠️♥️♣️♦️ JOUEUR 1️⃣ c'est à toi! Tu choisis ton combattant, puis un ennemi ♠️♥️♣️♦️♠️♥️♣️♦️
                
            """)
            
            playerRound(attacker: player1, defender: player2)
            numberRound += 1
            
            if teamIsAlive(player: player2) {
                print("""
                    
                🔸🔹🔶🔷🔸🔹🔶🔷 JOUEUR 2️⃣ c'est à toi! Tu choisis ton combattant, puis un ennemi 🔸🔹🔶🔷🔸🔹🔶🔷
                    
                """)
                
                playerRound(attacker: player2, defender: player1)
                
            }
        }
    }

}
 


