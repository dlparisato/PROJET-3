//
//  Weapon.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 12/02/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

class Weapon {
    

    // MARK: - PROPERTIES
    
    // On a besoin d'un nom arme' et de nombre dégâts
    var nameWeapon: String
    var damageWeapon: Int
    
    // Utiliser uniquement Wizard
    var heal: Int
    
    
    // MARK: - INITIALIZER
    
    // Initialisation des variables de classe:
    init(nameWeapon: String, damageWeapon: Int, heal: Int) {
        self.nameWeapon = nameWeapon
        self.damageWeapon = damageWeapon
        self.heal = heal
    }
    
    
    // MARK: - NO METHOD

}
