//
//  main.swift
//  Projet 3 GAME
//
//  Created by DL PARISATO on 22/01/2020.
//  Copyright © 2020 PARISATO. All rights reserved.
//

import Foundation

print("============================ W E L C O M E -- G A M E -- R P G ===============================")

// Creating a class Game instance
var game = Game()
game.start()

 

